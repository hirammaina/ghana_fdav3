<?php

return [
    'name' => 'ClinicalTrials'
];
