<?php

return [
    'name' => 'TraderManagement'
];
