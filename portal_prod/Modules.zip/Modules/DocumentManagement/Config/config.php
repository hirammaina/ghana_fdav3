<?php

return [
    'name' => 'DocumentManagement'
];
