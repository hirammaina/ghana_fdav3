<?php

return [
    'name' => 'PublicAccess'
];
