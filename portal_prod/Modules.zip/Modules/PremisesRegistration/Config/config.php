<?php

return [
    'name' => 'PremisesRegistration'
];
