<?php

return [
    'name' => 'Configurations'
];
