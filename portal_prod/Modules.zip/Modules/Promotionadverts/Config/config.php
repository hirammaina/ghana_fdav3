<?php

return [
    'name' => 'Promotionadverts'
];
