<?php

Route::group(['middleware' => 'web', 'prefix' => 'newreports', 'namespace' => 'App\\Modules\NewReports\Http\Controllers'], function()
{ 
    Route::get('getControlledDrugsSubModules', 'NewReportsController@getControlledDrugsSubModules');
     Route::get('getControlledDrugsPermitType', 'NewReportsController@getControlledDrugsPermitType');
    Route::get('getPermitType', 'NewReportsController@getPermitType');
    //product routes
    Route::get('getProductSummaryReport', 'NewReportsController@getProductSummaryReport');
    Route::get('printProductSummaryReport', 'NewReportsController@printProductSummaryReport');
    Route::get('productDetailedReportPreview', 'NewReportsController@productDetailedReportPreview');
    Route::get('exportDetailedReport', 'NewReportsController@exportDetailedReport');
    Route::get('exportProductSummaryReport', 'NewReportsController@exportProductSummaryReport');
    Route::get('printProductDetailedReport', 'NewReportsController@printProductDetailedReport');
    Route::get('getProductSummaryCartesianReport', 'NewReportsController@getProductSummaryCartesianReport');

    Route::get('getSectionParams', 'NewReportsController@getSectionParams');

    //end product routes
    //start premise routes
     Route::get('getPremiseSummaryReport', 'NewReportsController@getPremiseSummaryReport');
    Route::get('printPremiseSummaryReport', 'NewReportsController@printPremiseSummaryReport');
    Route::get('premiseDetailedReportPreview', 'NewReportsController@premiseDetailedReportPreview');
    Route::get('exportPremiseSummaryReport', 'NewReportsController@exportPremiseSummaryReport');
    Route::get('getPremiseSummaryCartesianReport', 'NewReportsController@getPremiseSummaryCartesianReport');
     //start import export routes 
     Route::get('getImportExportSummaryReport', 'NewReportsController@getImportExportSummaryReport');
    Route::get('printImportExportSummaryReport', 'NewReportsController@printImportExportSummaryReport');
    Route::get('importExportDetailedReportPreview', 'NewReportsController@importExportDetailedReportPreview');
    Route::get('importExportSummaryReportExport', 'NewReportsController@importExportSummaryReportExport');
    Route::get('getImportExportSummaryCartesianReport', 'NewReportsController@getImportExportSummaryCartesianReport');
     //start Gmp report routes 
    Route::get('getGmpSummaryReport', 'NewReportsController@getGmpSummaryReport');
    Route::get('printGmpSummaryReport', 'NewReportsController@printGmpSummaryReport');
    Route::get('gmpDetailedReportPreview', 'NewReportsController@gmpDetailedReportPreview');
    Route::get('gmpSummaryReportExport', 'NewReportsController@gmpSummaryReportExport');
    Route::get('getGmpSummaryCartesianReport', 'NewReportsController@getGmpSummaryCartesianReport');

    //start Clinical Trial report routes 
    Route::get('getClinicalTrialSummaryReport', 'NewReportsController@getClinicalTrialSummaryReport');
    Route::get('printClinicalTrialSummaryReport', 'NewReportsController@printClinicalTrialSummaryReport');
    Route::get('clinicalTrialDetailedReportPreview', 'NewReportsController@clinicalTrialDetailedReportPreview');
    Route::get('clinicalTrialSummaryReportExport', 'NewReportsController@clinicalTrialSummaryReportExport');
    Route::get('getClinicalTrialSummaryCartesianReport', 'NewReportsController@getClinicalTrialSummaryCartesianReport');

    //start Promotion & Advertisement report routes 
    Route::get('getPromotionAdvertisementSummaryReport', 'NewReportsController@getPromotionAdvertisementSummaryReport');
    Route::get('printPromotionAdvertisementSummaryReport', 'NewReportsController@printPromotionAdvertisementSummaryReport');
    Route::get('promotionAdvertisementDetailedReportPreview', 'NewReportsController@promotionAdvertisementDetailedReportPreview');
    Route::get('promotionAdvertisementSummaryReportExport', 'NewReportsController@promotionAdvertisementSummaryReportExport');
    Route::get('getPromotionAdvertisementSummaryCartesianReport', 'NewReportsController@getPromotionAdvertisementSummaryCartesianReport');


    //start Disposal report routes 
    Route::get('getDisposalSummaryReport', 'NewReportsController@getDisposalSummaryReport');
    Route::get('printDisposalSummaryReport', 'NewReportsController@printDisposalSummaryReport');
    Route::get('disposalDetailedReportPreview', 'NewReportsController@disposalDetailedReportPreview');
    Route::get('disposalSummaryReportExport', 'NewReportsController@disposalSummaryReportExport');
    Route::get('getDisposalSummaryCartesianReport', 'NewReportsController@getDisposalSummaryCartesianReport');


     //start Controlled Drugs routes 
     Route::get('getControlledDrugsImportPermitSummaryReport', 'NewReportsController@getControlledDrugsImportPermitSummaryReport');
    Route::get('printControlledDrugsImportPermitSummaryReport', 'NewReportsController@printControlledDrugsImportPermitSummaryReport');
    Route::get('controlledDrugsImportPermitDetailedReportPreview', 'NewReportsController@controlledDrugsImportPermitDetailedReportPreview');
    Route::get('controlledDrugsImportPermitSummaryReportExport', 'NewReportsController@controlledDrugsImportPermitSummaryReportExport');
    Route::get('getControlledDrugsImportPermitSummaryCartesianReport', 'NewReportsController@getControlledDrugsImportPermitSummaryCartesianReport');
    //Order of supply and Approval Certificate
      Route::get('getCertificateOrderSummaryReport', 'NewReportsController@getCertificateOrderSummaryReport');
    Route::get('printCertificateOrderSummaryReport', 'NewReportsController@printCertificateOrderSummaryReport');
    Route::get('controlledDrugsDetailedReportPreview', 'NewReportsController@controlledDrugsDetailedReportPreview');
    Route::get('certificateOrderSummaryReportExport', 'NewReportsController@certificateOrderSummaryReportExport');
    Route::get('getCertificateOrderSummaryCartesianReport', 'NewReportsController@getCertificateOrderSummaryCartesianReport');
    Route::get('getImportExportPermitType', 'NewReportsController@getImportExportPermitType');
   
   
});