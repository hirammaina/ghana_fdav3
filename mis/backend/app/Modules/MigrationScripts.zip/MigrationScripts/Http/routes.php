<?php

Route::group([ 'prefix' => 'migrationscripts', 'namespace' => 'App\\Modules\MigrationScripts\Http\Controllers'], function()
{
    Route::get('/', 'MigrationScriptsController@index');
    Route::get('initiatVetemigrateNewProductsDetails','MigrationScriptsController@initiatVetemigrateNewProductsDetails');
    Route::get('initiatNewMedicinesProductsemigrateDetails','MigrationScriptsController@initiatNewMedicinesProductsemigrateDetails');
	
	 Route::get('initiatNewMedicaldevicesProductsemigrateDetails','MigrationScriptsController@initiatNewMedicaldevicesProductsemigrateDetails');
    Route::get('testemail','MigrationScriptsController@testemail');

     Route::get('initiatemappingProductRegistrationSubmission','MigrationScriptsController@initiatemappingProductRegistrationSubmission');
Route::get('initiatTobaccoProductsemigrateDetails','MigrationScriptsController@initiatTobaccoProductsemigrateDetails');
     
     Route::get('initiatNewFoodProductsemigrateDetails','MigrationScriptsController@initiatNewFoodProductsemigrateDetails');
     Route::get('initiatNewCosmeticsProductsemigrateDetails','MigrationScriptsController@initiatNewCosmeticsProductsemigrateDetails');
	 
     Route::get('initiatemigrateClinicalTrialDatasets','MigrationScriptsController@initiatemigrateClinicalTrialDatasets');
     Route::get('initiatemigratePromotionalDatasets','MigrationScriptsController@initiatemigratePromotionalDatasets');
Route::get('initiatemappingClincialTrialRegistrationSubmission','MigrationScriptsController@initiatemappingClincialTrialRegistrationSubmission');
Route::get('initiatePremisesDataMapping','MigrationScriptsController@initiatePremisesDataMapping');
  
    Route::get('initiateGmpRegistrationMigration','MigrationScriptsController@initiateGmpRegistrationMigration');
    Route::get('initiateMedProductAuthorisationMigration','MigrationScriptsController@initiateMedProductAuthorisationMigration');
   Route::get('initiatevetProductAuthorisationMigration','MigrationScriptsController@initiatevetProductAuthorisationMigration');
   Route::get('initiateCosmeticsProductAuthorisationMigration','MigrationScriptsController@initiateCosmeticsProductAuthorisationMigration');
   
   Route::get('initiateFoodPremisesDataMapping','MigrationScriptsController@initiateFoodPremisesDataMapping');
  //migration_food_premises
  Route::get('initiatemappingPremisesSubmission','MigrationScriptsController@initiatemappingPremisesSubmission');
  
  
  Route::get('getAppdataMigrationRequests','MigrationScriptsController@getAppdataMigrationRequests');
Route::get('getProductAppdataMigrationDetails','MigrationScriptsController@getProductAppdataMigrationDetails');
  
Route::get('getAppDataMigrationsGridColumnsConfig','MigrationScriptsController@getAppDataMigrationsGridColumnsConfig');
  
Route::get('downloadappdatamigrationuploadTemplate','MigrationScriptsController@downloadappdatamigrationuploadTemplate');
Route::post('saveappdatamigrationuploads','MigrationScriptsController@saveappdatamigrationuploads');

Route::post('deleteApplicationMigratedDataSets','MigrationScriptsController@deleteApplicationMigratedDataSets');
Route::post('synApplicationMigratedDataSets','MigrationScriptsController@synApplicationMigratedDataSets');
Route::get('getParameterFormColumnsConfig','MigrationScriptsController@getParameterFormColumnsConfig');
Route::get('mapNewWorkflowfromExisting','MigrationScriptsController@mapNewWorkflowfromExisting');


Route::get('remapProductAuthorisationManuacturer','MigrationScriptsController@remapProductAuthorisationManuacturer');
Route::get('remapImportApplicationsToPortal','MigrationScriptsController@remapImportApplicationsToPortal');
  
  
    Route::get('initiatemappingGmpSubmission','MigrationScriptsController@initiatemappingGmpSubmission');
  Route::get('initiatemappingPromotionsSubmission','MigrationScriptsController@initiatemappingPromotionsSubmission');
  
 Route::get('initiateMedProductDatabaseMigration','MigrationScriptsController@initiateMedProductDatabaseMigration');
});
